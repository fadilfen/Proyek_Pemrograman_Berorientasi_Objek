package tubes_a11;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;

public class MentalWellbeingApp extends JFrame {
    private User user;
    private JLabel tokenLabel, scoreLabel, screenTimeLabel;
    private DefaultTableModel activityModel;
    
    // --- Palette Warna Modern ---
    private final Color COLOR_PRIMARY = new Color(74, 144, 226); // Blue
    private final Color COLOR_SUCCESS = new Color(46, 204, 113); // Green
    private final Color COLOR_DANGER  = new Color(231, 76, 60);  // Red
    private final Color COLOR_BG      = new Color(248, 249, 250); // Light Grayish Blue
    private final Color COLOR_CARD    = Color.WHITE;
    private final Font FONT_BOLD      = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_REGULAR   = new Font("Segoe UI", Font.PLAIN, 13);

    public MentalWellbeingApp() {
        loginScreen();
    }

    private void loginScreen() {
        JFrame login = new JFrame("Welcome Back");
        login.setSize(400, 300);
        login.setLocationRelativeTo(null);
        login.setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(COLOR_BG);
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel title = new JLabel("Login Dashboard", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(COLOR_PRIMARY);

        JTextField username = new JTextField();
        JPasswordField password = new JPasswordField();
        JButton btn = createStyledButton("LOGIN", COLOR_PRIMARY);

        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        mainPanel.add(title, gbc);
        
        gbc.gridy = 1; gbc.gridwidth = 1; gbc.insets = new Insets(20, 5, 5, 5);
        mainPanel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1; mainPanel.add(username, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.insets = new Insets(5, 5, 5, 5);
        mainPanel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1; mainPanel.add(password, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2; gbc.insets = new Insets(20, 5, 5, 5);
        mainPanel.add(btn, gbc);

        btn.addActionListener(e -> {
            if (username.getText().equals("admin") && new String(password.getPassword()).equals("12345")) {
                user = new User(1, "James Luck", 50);
                login.dispose();
                initUI();
            } else {
                JOptionPane.showMessageDialog(login, "Username atau Password Salah!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        login.add(mainPanel);
        login.setVisible(true);
    }

    private void initUI() {
        setTitle("MindFull - Mental Health Tracker");
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(COLOR_BG);
        setLayout(new BorderLayout(20, 20));

        // --- Header / Dashboard Cards ---
        JPanel headerPanel = new JPanel(new GridLayout(1, 3, 20, 0));
        headerPanel.setOpaque(false);
        headerPanel.setBorder(new EmptyBorder(25, 25, 10, 25));

        tokenLabel = createDashboardCard("Tokens Available", "0", new Color(155, 89, 182));
        scoreLabel = createDashboardCard("Wellness Score", "0", COLOR_SUCCESS);
        screenTimeLabel = createDashboardCard("Screen Time", "0 min", COLOR_PRIMARY);

        headerPanel.add(tokenLabel);
        headerPanel.add(scoreLabel);
        headerPanel.add(screenTimeLabel);

        // --- Tabs ---
        UIManager.put("TabbedPane.selected", Color.WHITE);
        UIManager.put("TabbedPane.contentAreaColor", Color.WHITE);
        
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(FONT_BOLD);
        tabs.setBorder(new EmptyBorder(10, 25, 25, 25));

        tabs.addTab("  Activity Tracker  ", createActivityPanel());
        tabs.addTab("  Top Up Balance  ", createTopUpPanel());
        tabs.addTab("  Health Report  ", createReportPanel());

        add(headerPanel, BorderLayout.NORTH);
        add(tabs, BorderLayout.CENTER);
        
        refreshDashboard();
        setVisible(true);
    }

    private JLabel createDashboardCard(String title, String value, Color accent) {
        JLabel label = new JLabel("<html><div style='text-align: center; padding: 10px;'>"
                + "<span style='font-size: 10px; color: gray;'>" + title + "</span><br>"
                + "<span style='font-size: 18px; font-weight: bold; color: " + getHex(accent) + ";'>" + value + "</span>"
                + "</div></html>");
        label.setOpaque(true);
        label.setBackground(COLOR_CARD);
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setBorder(BorderFactory.createMatteBorder(0, 0, 4, 0, accent));
        return label;
    }

    private JPanel createActivityPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(COLOR_CARD);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        // Form Section
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        String[] apps = {"TikTok", "Instagram", "YouTube", "WhatsApp", "Netflix", "Spotify"};
        JComboBox<String> appName = new JComboBox<>(apps);
        JTextField duration = new JTextField();
        JTextField limit = new JTextField();
        JButton addBtn = createStyledButton("Log Activity (-5 Tokens)", COLOR_PRIMARY);

        gbc.gridx = 0; gbc.gridy = 0; form.add(new JLabel("App Name:"), gbc);
        gbc.gridx = 1; form.add(appName, gbc);
        gbc.gridx = 0; gbc.gridy = 1; form.add(new JLabel("Duration (Min):"), gbc);
        gbc.gridx = 1; form.add(duration, gbc);
        gbc.gridx = 0; gbc.gridy = 2; form.add(new JLabel("Daily Limit:"), gbc);
        gbc.gridx = 1; form.add(limit, gbc);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2; form.add(addBtn, gbc);

        // Table Section
        activityModel = new DefaultTableModel(new String[]{"App", "Duration", "Limit", "Status"}, 0);
        JTable table = new JTable(activityModel);
        styleTable(table);

        addBtn.addActionListener(e -> {
            try {
                if (user.getToken() < 5) {
                    JOptionPane.showMessageDialog(this, "Token tidak cukup!", "Warning", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                AktivitasDigital act = new AktivitasDigital(
                    appName.getSelectedItem().toString(),
                    Integer.parseInt(duration.getText()),
                    Integer.parseInt(limit.getText())
                );
                user.tambahAktivitas(act);
                user.kurangiToken(5);
                
                String status = act.melebihiBatas() ? "OVER LIMIT" : "HEALTHY";
                activityModel.addRow(new Object[]{act.getNamaAplikasi(), act.getDurasiMenit(), act.getBatasDurasi(), status});
                refreshDashboard();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Mohon masukkan angka valid");
            }
        });

        panel.add(form, BorderLayout.WEST);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private JPanel createTopUpPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(COLOR_CARD);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField jumlah = new JTextField(15);
        JComboBox<String> metode = new JComboBox<>(new String[]{"QRIS (Instant)", "Bank Transfer", "E-Wallet"});
        JButton btn = createStyledButton("Proses Top Up", COLOR_SUCCESS);

        gbc.gridx = 0; gbc.gridy = 0; panel.add(new JLabel("Amount:"), gbc);
        gbc.gridx = 1; panel.add(jumlah, gbc);
        gbc.gridx = 0; gbc.gridy = 1; panel.add(new JLabel("Method:"), gbc);
        gbc.gridx = 1; panel.add(metode, gbc);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2; panel.add(btn, gbc);

        btn.addActionListener(e -> {
            try {
                TopUp topUp = new TopUp(Integer.parseInt(jumlah.getText()), metode.getSelectedItem().toString());
                topUp.prosesTopUp(user);
                refreshDashboard();
                JOptionPane.showMessageDialog(this, "Top up berhasil ditambahkan!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Jumlah tidak valid");
            }
        });

        return panel;
    }

    private JPanel createReportPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setBackground(COLOR_CARD);
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setFont(new Font("Monospaced", Font.PLAIN, 12));
        area.setBackground(new Color(250, 250, 250));
        
        JButton generate = createStyledButton("Generate Summary Report", COLOR_PRIMARY);
        generate.addActionListener(e -> area.setText(user.lihatLaporan().generateLaporan()));

        panel.add(generate, BorderLayout.NORTH);
        panel.add(new JScrollPane(area), BorderLayout.CENTER);
        return panel;
    }

    // --- Helper UI Methods ---
    
    private void refreshDashboard() {
        tokenLabel.setText("<html><div style='text-align: center;'><span style='font-size: 10px; color: gray;'>Tokens Available</span><br>"
                + "<span style='font-size: 18px; font-weight: bold; color: #9b59b6;'>" + user.getToken() + "</span></div></html>");
        scoreLabel.setText("<html><div style='text-align: center;'><span style='font-size: 10px; color: gray;'>Wellness Score</span><br>"
                + "<span style='font-size: 18px; font-weight: bold; color: #2ecc71;'>" + user.hitungScoreKesehatan() + "</span></div></html>");
        screenTimeLabel.setText("<html><div style='text-align: center;'><span style='font-size: 10px; color: gray;'>Screen Time</span><br>"
                + "<span style='font-size: 18px; font-weight: bold; color: #4a90e2;'>" + user.hitungTotalScreenTime() + " min</span></div></html>");
    }

    private JButton createStyledButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BOLD);
        btn.setForeground(Color.WHITE);
        btn.setBackground(color);
        btn.setFocusPainted(false);
        btn.setBorder(new EmptyBorder(10, 20, 10, 20));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void styleTable(JTable table) {
        table.setRowHeight(30);
        table.setFont(FONT_REGULAR);
        table.getTableHeader().setFont(FONT_BOLD);
        table.getTableHeader().setBackground(COLOR_PRIMARY);
        table.getTableHeader().setForeground(Color.WHITE);
        table.setSelectionBackground(new Color(232, 240, 254));
        table.setShowVerticalLines(false);
        table.setGridColor(new Color(230, 230, 230));
    }

    private String getHex(Color c) {
        return String.format("#%02x%02x%02x", c.getRed(), c.getGreen(), c.getBlue());
    }
}